**This website is to help with any students who are stuggling with maths in school**

MathJAX is one of the plugins used to display the math formulae, here is the documentation:
https://docs.mathjax.org/en/latest/